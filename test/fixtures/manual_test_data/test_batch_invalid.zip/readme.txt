This is not a valid X12 file
Just plain text
